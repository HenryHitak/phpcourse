<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hitak_mydetails</title>
</head>
<body>
    <?php
    echo "<h2>My first name is Hitak.</h2>";
    echo "<h2>My last name is Lee.</h2>";
    $img = "https://cdn.pixabay.com/photo/2012/04/13/12/39/south-32234__340.png"; // variable for img address
    echo "<h2>My country's flag is </h2>".'<img src="'.$img.'">'; //display img with src
    ?>
</body>
</html>